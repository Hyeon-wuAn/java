/**
 * 
 */
/**
 * @author 6A
 *
 */
module java1 {
}