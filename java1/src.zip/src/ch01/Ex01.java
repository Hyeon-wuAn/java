package ch01;

public class Ex01 {
	public static void main(String[] args) {
		System.out.println("안녕");
		// 한줄 주석
		/*
		. : 알고있다, 가지고 있다
			C.Program Files..Java.jdk-11
			안현우.글로벌아이티.6층
		;(세미콜론) : 실행문
			문장의 마침표
		클래스 이름 명명 규칙
			겹치지 않게 사용
			구별할 것을 사용(_붙이기, 숫자 붙이기 등등)
			특수문자 _ $ 두가지만 사용 가능
			첫글자는 대문자 알파벳(숫자, 특수문자X)
			SportsScore : 단어의 조합은 첫글자 대문자로(관례)
		들여쓰기 : Tab
		실행 단축키 : Ctrl+F11 	
		 */
		
	}
}
