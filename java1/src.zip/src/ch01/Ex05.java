package ch01;

public class Ex05 {
	public static void main(String [] args) {
		// String 문자
		// 기본 데이터 타입은 아님
		String a;
		a = "hello";		 // ""(큰따옴표) 안에 사용해야 한다.
		System.out.println(a);
		
		String b = "  ";      // " "(공백)도 문자로 인식.
		System.out.println(b);
		
		String c = "hello world";
		System.out.println(c);
		
		
		
		
	}
}
