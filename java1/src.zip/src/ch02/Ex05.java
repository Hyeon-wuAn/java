package ch02;

public class Ex05 {
	public static void main(String[] args) {
		// 비교연산자
		// ( == , > , < , >= , <= , != )
		// 비교연산자의 결과는 논리형
//		System.out.println(10>0);
//		System.out.println(10==0);
//		System.out.println(10==0+10);
//		System.out.println(10!=0);
//		
//		// 변수 활용 
//		int a = 10, b = 0;
//		System.out.println(a>=b);
//		System.out.println(a==b+10);
//		System.out.println(a!=b);
//		System.out.println();
		

			int a =0;
			int b;
			for(b=1; b<=100; b+=2) {
				a+=b; // a=1+3+5
			// a=a+b (0 +1 +3 +5)
			}
			System.out.println(a);
			
			
			
			
	}
}
