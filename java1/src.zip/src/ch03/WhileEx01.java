package ch03;

public class WhileEx01 {	// 반복문
	public static void main(String args) {
		// while문
		// for문 <-> while 문으로 바꿔보는 연습!

		
		int a = 0;			// 초기식
		while(a<3) {		// 조건식
			System.out.println("hello");
			a++;			// 증감식
			}// while문 종료.
		
		System.out.println("--------------------------");
		
		int b = 0;
		while(b<3) {
			b++;
			System.out.println("hihihi");
		}
		
		
		
	}
}
