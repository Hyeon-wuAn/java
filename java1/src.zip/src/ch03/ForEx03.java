package ch03;

public class ForEx03 {
	public static void main(String[] args) {
		// 1~100까지 홀수만 출력
		for(int a=2; a<=100; a+=2) { // a+=2  ==  a=a+2
			System.out.println(a);
		}
		
		
		
		
		
		
		
	}
}
