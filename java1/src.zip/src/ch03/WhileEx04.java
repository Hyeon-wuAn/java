package ch03;

public class WhileEx04 {
	public static void main(String[] args) {
		int sum = 0;
		int i = 1;		// 초기식
		while(i<=5) {	// 조건식
			sum+=i;
			i++;		// 증감식
		}
		System.out.println(sum);
		
		//1부터 100까지의 합
		int sum2 = 0;
		int a = 1;
		while(a<=100) {
			sum2+=a;
			a++;
		}
		System.out.println(sum2);
		
		//1부터 100까지 홀수 출력
		
		//1부터 100까지 짝수 출력
		
		
		
		
		
	}
}
