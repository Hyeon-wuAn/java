package ch03;

public class DoWhileEx02 {
	public static void main(String[] args) {
		int num = 2;
		do {
			System.out.println("hello");
			num++;
		}while(num<=1);  // 끝이 while 이기 때문에 ;(세미콜론)으로 끝남.
	}
}
