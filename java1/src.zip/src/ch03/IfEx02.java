package ch03;

public class IfEx02 {
	public static void main(String[] args) {
		int score = 93; //점수 (나중에 이런식으로(//점수처럼) 주석 달아서 인수인계 할 수 있음)
//		if(score>90) {
//			System.out.println("점수가 90보다 큽니다.");
//			System.out.println("등급은 A입니다");
//		}
		
		if(score<90) {
			System.out.println("점수가 90보다 작습니다");
		}
			System.out.println("등급은 B입니다");
		
		
		
	}
}
