package ch03;

public class ForEx06 {
	public static void main(String[] args) {
		for(int a=1; a<=7; ) { 
			System.out.println("hello world");
		}
		// 증감식에 따른(증감식 없이) 조건식이 계속 t면 무한루프에 빠짐.
	}
}
