package ch03;

public class ForEx01 {
	public static void main(String[] args) {
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		// 수정할때 하나하나 손봐야한다.
		System.out.println("---------------------------");
		for(int a=1; a<=7; a++) {
			System.out.println("hello world");
		}
		// 위와 같은 결과가 나오지만 유지/보수 편함.
		
		
	}
}
