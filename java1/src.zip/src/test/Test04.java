package test;

public class Test04 {
	public static void main(String[] args) {
		int a,b;
		for(a=0; a<5; a++) {   // 세로줄 반복
			for(b=1; b<=5; b++) {   // 가로로 1~5까지
				System.out.print(a+b);	// a+b 를 가로로 출력.
			}
			System.out.println();	// 줄바꿈
		}
		
		
		
		
		
		
	}
}
