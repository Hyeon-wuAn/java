package test;

public class Test05 {
	public static void main(String[] args) {
		int a,b;
		for(a=0; a<=4; a++) {
			for(b=5; b<=9; b++) {
				System.out.print(b-a);
			}
			System.out.println();
		}
		
		
		
		
		
	}
}
