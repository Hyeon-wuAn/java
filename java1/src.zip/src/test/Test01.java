package test;

public class Test01 {
	public static void main(String[] args) {
		int a;
		for(a=1; a<=5; a++) {
			System.out.println(a+"행"+" : "+"***");
		}

		
		
		
	}
}
