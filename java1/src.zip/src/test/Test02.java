package test;

public class Test02 {
	public static void main(String[] args) {
		int a,b;
		for(a=1; a<=5; a++) {
			for(b=1; b<=a; b++) {	//b가 a보다 작거나 같을때까지 반복.
				System.out.print("*"); // ln : 줄바꿈
			}
			System.out.println();    // 줄바꿈 용도의 실행값
		}
		
		
		
		
		
	}
}
