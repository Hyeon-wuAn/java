package day03;

public class Ex08 {
	public static void main(String[] args) {
		//반복문 = for문
		
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		System.out.println("hello world");
		// 수정할때는 하나하나 전부 수정해야함
		
		System.out.println("-----------");
		
		for(int a=1; a<=6; a++) {
			System.out.println("helloo world");
		}
		//결과는 위와 같지만 유지/보수 쉬움.
		
	}
}
