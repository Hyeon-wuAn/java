package day03; 

public class Ex02 {
	public static void main(String[] args) {
		// if-else문
		int a = 10;
		if(a<0) {
			//조건식이 true 일때
			System.out.println("크다");
		}else {    //필수 아님! 선택적 사용, 단독사용 불가
			//조건식이 false일때
		    System.out.println("작다");
		}
	    System.out.println(a);
		
		
		
	}
}
