package day03;

public class Ex13 {
	public static void main(String[] args) {
		// for문
        // 1~10 까지의 합
		
		int sum=1;
		for(int i=2; i<=10; i++) {
			sum+=i;     //sum = sum+i
		}
		System.out.println(sum);
		
		// 1~100까지 홀수의 합
		

		
		
		
		
	}
}
