package day03;

public class Ex01 {
	public static void main(String[] args) {
		// if문
		// 블럭 {} 안에서는 모든 문법 사용 가능
		// if(조건식){
	    // 조건식의 결과가 true일때 실행
		// }
		System.out.println("aaaa");
		if(10<0){
			//조건식의 결과가 true일때 실행된다.
			System.out.println("true");
		}
		
		System.out.println("bbbb");
		
		
//		int a = 6;
//		if(a>0) {
//			a += 4; // a 에 4가 더해진다
//			System.out.println(a);
//		}
//		System.out.println(a);
		
		int a =6;
		int b;
		if(a<5) {
			b =10;
		} else {
			b=0;
		}
		System.out.println(b);
		
		
	}

}
