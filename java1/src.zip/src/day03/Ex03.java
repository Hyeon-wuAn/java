package day03;

public class Ex03 {
	public static void main(String[] args) {
		// else-if문
		int a = 6;
		if(a>100) {
			System.out.println("if문 true");
		}else if(a>50 ) {              // 여러개 사용 가능
			System.out.println("else if true");
		}else if(a>0) {
			System.out.println("else if2 true");
		}else {                        // 문법상 마지막에 위치
			System.out.println("else true");
		}
		
		
		
		
	}

}
