package day03;

public class Ex05 {
	public static void main(String[] args) {
		//중첩 if문
		int a = 20;
		if(a>100) {
			if(a>200) {
				// true
			}else {
				// false	
				if(a>50) {
				
				}else {
					
				}
			}
		} //if문 끝. 문법상으로 가능.
		
		
		
		
		
		
		
		
		
	}

}
