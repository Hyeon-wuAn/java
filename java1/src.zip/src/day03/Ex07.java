package day03;

public class Ex07 {
	public static void main(String[] args) {
		int a = 100;
		if(a>10) {
			int x= 1000;
			System.out.println(a);
			System.out.println(x);
		}
		System.out.println(a);
//		System.out.println(x); //if문 밖에서는 선언된적 없으므로 오류
		
		
		
		
		
		
	}
}
