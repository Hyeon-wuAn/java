package day03;

public class Ex11 {
	public static void main(String[] args) {
		// for문 속 for문
		int a;
		for(a=1; a<=5; a++) {
			for(int b=1; b<=5; b++) {  // a의 입장에서 하나의 실행문
				System.out.println(a+" "+b);
			}
		}
		
		
		
		
		
		
		
		
		
		
	}
}
