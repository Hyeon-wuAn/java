package day03;

public class Ex90 {
	public static void main(String[] args) {
		
	}
}
