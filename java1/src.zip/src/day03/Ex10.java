package day03;

public class Ex10 {
	public static void main(String[] args) {
		// 반복문에서는 무한반복 주의
		// 증감식으로 반복문 횟수 정해주기
		for(int a=1; a<10;  ) {
			System.out.println("안녕");
		}
		
		
		
		
		
		
		
		
	}
}
