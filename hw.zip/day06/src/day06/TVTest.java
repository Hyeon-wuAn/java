package day06;

public class TVTest {
	public static void main(String[] args) {
		TV myTV = new TV("SAMSUNG",2021,66);
		myTV.showInfo();
	}
}	