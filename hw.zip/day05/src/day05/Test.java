package day05;

public class Test {
	public static void main(String[] args) {
		System.out.println("집에서 작업 했음");
		System.out.println("학원에서 다시 작업 좀 헷갈림....");
		System.out.println("test중");
		System.out.println("endendendend");
	}
}
