package a1;

public class A06 {
	public static void main(String[] args) {
		//1~20
		int a;
		for(a=1; a<=20; a++) {
			if(a%2==1) {
				System.out.println(a+"는 홀수");
			}else {
				System.out.println(a+"는 짝수");
			}
		}
		
		
		
		
		
	}
}
