package a1;

public class A11 {
	public static void main(String[] args) {
		//while문
		int a =1;
		while(a<=5) {
			System.out.println(a);
			a++;
		}
		
		int b =1;
		do {
			System.out.println(b);
			b++;
		}while(b<10);


		
		
	}
}
