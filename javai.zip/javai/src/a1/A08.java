package a1;

public class A08 {
	public static void main(String[] args) {
		int dan, num;
		for(dan=2; dan<=9; dan++) {
			for(num=1; num<=9; num++) {
				System.out.println(dan+"X"+num+"="+dan*num);					
			}
		}
		
		int i=1;
		while(true) {
			System.out.println(i);
			i++;
	
		}
		
	}
}
