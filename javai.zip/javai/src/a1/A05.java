package a1;

public class A05 {
	public static void main(String[] args) {
		//10~20까지 홀짝
		int a;
		for(a=10; a<=20; a++) {
			if(a%2==0) {
				System.out.println(a+"= 짝수");
			}else {
				System.out.println(a+"= 홀수");
			}
		}
		
		
		
		
	}
}
