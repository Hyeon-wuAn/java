package a2;

public class A06 {
	public static void main(String[] args) {
		double scoreList[][] = {{4.49,4.38}, {2.34,3.5}, {3.87,2.88}, {4.1,3.9}};
		// year, term
		for(year=0; year<scoreList.length; year++) {
			for(term=0; ter)
		}
		
		
		
		
	}
}
